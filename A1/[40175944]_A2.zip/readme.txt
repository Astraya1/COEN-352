Here is where all the methods are implemented for the questions:

Question 1.1) createIndex method was implemented in DLDictionary.java
Question 1.2) BSTIndex method was implemented in DLDictionary.java
Question 2) query method was implemented in WarehouseInventory.java
Question 3) Unit tests implemented as JUnit 5 tests in JUnitTests.java

Testing for all methods was done in JUnitTests.java